import { useEffect, useState } from "react";
import "./App.css";

const LIMIT = 10;
const KEY = "closed-list:v1";
const EMPTY = { open: [], closed: [], done: 0 };

function load() {
  try {
    return JSON.parse(localStorage.getItem(KEY)) ?? EMPTY;
  } catch {
    return EMPTY;
  }
}

const uid = () => Math.random().toString(36).slice(2) + Date.now().toString(36);

export default function App() {
  const [state, setState] = useState(load);
  const [text, setText] = useState("");
  const { open, closed, done } = state;
  const full = closed.length >= LIMIT;

  useEffect(() => {
    try {
      localStorage.setItem(KEY, JSON.stringify(state));
    } catch {
      /* storage unavailable: keep working in memory */
    }
  }, [state]);

  const capture = (e) => {
    e.preventDefault();
    const t = text.trim();
    if (!t) return;
    setState((s) => ({ ...s, open: [{ id: uid(), text: t }, ...s.open] }));
    setText("");
  };

  // Only moves if the closed list has room. The cap is enforced here, not just in the UI.
  const commit = (id) =>
    setState((s) => {
      const item = s.open.find((i) => i.id === id);
      if (!item || s.closed.length >= LIMIT) return s;
      return {
        ...s,
        open: s.open.filter((i) => i.id !== id),
        closed: [...s.closed, item],
      };
    });

  const finish = (id) =>
    setState((s) => ({
      ...s,
      closed: s.closed.filter((i) => i.id !== id),
      done: s.done + 1,
    }));

  const letGo = (list, id) =>
    setState((s) => ({ ...s, [list]: s[list].filter((i) => i.id !== id) }));

  return (
    <main className="app">
      <header className="head">
        <h1>Closed list</h1>
        <p className="lede">
          Everything you could do goes on the open list. Only ten things get to
          be on the closed list, and nothing new gets in until something
          leaves.
        </p>
      </header>

      <section className="meter" aria-label={`${closed.length} of ${LIMIT} slots used`}>
        <div className="slots" aria-hidden="true">
          {Array.from({ length: LIMIT }, (_, i) => (
            <span key={i} className={i < closed.length ? "slot on" : "slot"} />
          ))}
        </div>
        <p className={full ? "status full" : "status"} role="status">
          {full
            ? "Closed list is full. Finish or let go of something to make room."
            : `${LIMIT - closed.length} of ${LIMIT} slots free. ${done} finished so far.`}
        </p>
      </section>

      <div className="cols">
        <section className="col" aria-labelledby="closed-h">
          <h2 id="closed-h">Closed list</h2>
          {closed.length === 0 ? (
            <p className="empty">Nothing committed. Pick from the open list.</p>
          ) : (
            <ul>
              {closed.map((item) => (
                <li key={item.id} className="item closed">
                  <span className="txt">{item.text}</span>
                  <button className="btn primary" onClick={() => finish(item.id)}>
                    Finish
                  </button>
                  <button
                    className="btn ghost"
                    onClick={() => letGo("closed", item.id)}
                    aria-label={`Let go of ${item.text}`}
                  >
                    Let go
                  </button>
                </li>
              ))}
            </ul>
          )}
        </section>

        <section className="col" aria-labelledby="open-h">
          <h2 id="open-h">Open list</h2>
          <form onSubmit={capture} className="capture">
            <input
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Capture anything"
              aria-label="Capture a task"
            />
            <button className="btn primary" type="submit">
              Add
            </button>
          </form>
          {open.length === 0 ? (
            <p className="empty">Empty. Capture what's on your mind.</p>
          ) : (
            <ul>
              {open.map((item) => (
                <li key={item.id} className="item">
                  <span className="txt">{item.text}</span>
                  <button
                    className="btn"
                    disabled={full}
                    title={full ? "Closed list is full" : "Move to closed list"}
                    onClick={() => commit(item.id)}
                  >
                    Commit
                  </button>
                  <button
                    className="btn ghost"
                    onClick={() => letGo("open", item.id)}
                    aria-label={`Let go of ${item.text}`}
                  >
                    Let go
                  </button>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>
    </main>
  );
}
